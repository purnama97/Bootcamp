<?php
	
	$conn = mysqli_connect("localhost","root","","webrole");
	$query = mysqli_query($conn,"SELECT * FROM hero WHERE id= '".$_GET['id']."'");
	while($row = mysqli_fetch_array($query))
	{
		unlink('img/'.$row[3]);
	}
	$query = mysqli_query($conn,"DELETE FROM hero WHERE id= '".$_GET['id']."'");
	if($query)
	{
		header('location:index.php');
	}
?>