<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Hero | WEB Role</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">HERO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="inputrole.php">Tambah Role</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="inputhero.php">Tambah Hero</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
	<br>
    <!-- Page Features -->
	<?php
	$conn = mysqli_connect("localhost","root","","webrole");
	$query = mysqli_query($conn,"SELECT * FROM hero");
	?>
    <div class="row text-center">
	<?php
	while($row = mysqli_fetch_array($query))
	{
	?>
      <div class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="<?php echo 'img/'.$row[3]; ?>" alt="">
          <div class="card-body">
            <h4 class="card-title"><?php echo $row[1]; ?></h4>
            <p class="card-text">
				<?php 
					$des = explode(" ",$row[4]);
					for($i=0;$i<=10;$i++)
					{
						echo $des[$i].' ';
						if($i >= 10)
						{
							echo "[..]";
						}
					}
					
				?></p>
          </div>
          <div class="card-footer">
            <a href="detail.php?id=<?php echo $row[0];?>" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
	<?php
	}
	?>
    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Ipur Purnama 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
