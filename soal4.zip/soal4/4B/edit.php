<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Hero | WEB Role</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">HERO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="inputrole.php">Tambah Role</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="inputhero.php">Tambah Hero</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
	<br>
    <!-- Page Features -->
    <div class="row">
	<div class="box box-lg col-md-8">
	<?php
	
	$conn = mysqli_connect("localhost","root","","webrole");
	$query = mysqli_query($conn,"SELECT * FROM hero WHERE id_hero= '".$_GET['id']."'");
	$prm = mysqli_fetch_array($query);
	?>
	<form action="#" method="POST" enctype="multipart/form-data">
	  <div class="form-group row">
		<label for="inputPassword3" class="col-sm-2 col-form-label">Nama Hero</label>
		<div class="col-sm-10">
		  <input type="text" name="namahero" required class="form-control" id="inputPassword3" placeholder="Masukan Nama Role" value="<?php echo $prm[1];?>">
		</div>
	  </div>
	  <div class="form-group row">
		<label for="inputPassword3" class="col-sm-2 col-form-label">Role</label>
		<div class="col-sm-10">
		  <select name="role" required class="form-control" id="inputPassword3">
			<?php
				$conn = mysqli_connect("localhost","root","","webrole");
				$query = mysqli_query($conn,"SELECT * FROM role");
				echo "<option value=''>-- Pilih Role --</option>";
				while($row = mysqli_fetch_array($query))
				{
					$pilih ="";
					if($row[0]==$prm[2]){ $pilih = "selected"; }
					echo "<option ".$pilih." value='$row[0]'>$row[1]</option>";
				}
	
			?>
		  </select>
		</div>
	  </div>
	  <div class="form-group row">
		<label for="inputPassword3" class="col-sm-2 col-form-label">Gambar</label>
		<div class="col-sm-10">
		  <input type="file" name="file" class="form-control" id="inputPassword3" placeholder="Masukan Nama Role">
		  <img src="img/<?php echo $prm[3]; ?>" width="350px" height="250px">
		</div>
	  </div>
	  <div class="form-group row">
		<label for="inputPassword3" class="col-sm-2 col-form-label">Deskripsi</label>
		<div class="col-sm-10">
		  <textarea name="deskripsi" required class="form-control"><?php echo $prm[4];?></textarea>
		</div>
	  </div>
		<div class="col-sm-10">
		  <input type="submit" name="simpan" class="btn btn-primary" value="Simpan">
		  <button type="Reset" class="btn btn-warning">Reset</button>
		</div>
	</form>
    </div>
	</div>
	<br>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Ipur Purnama 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
<?php
	if(@$_POST['simpan'])
	{
		if(@$_FILES['file']['name'] != "")
		{
			$ekstensi_diperbolehkan	= array('png','jpg');
			$nama = $_FILES['file']['name'];
			$x = explode('.', $nama);
			$ekstensi = strtolower(end($x));
			$ukuran	= $_FILES['file']['size'];
			$file_tmp = $_FILES['file']['tmp_name'];	
			unlink("img/".$prm[3]);
			
			if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
				if($ukuran < 1044070){			
					move_uploaded_file($file_tmp, 'img/'.$nama);
					$conn = mysqli_connect("localhost","root","","webrole");
					$query = mysqli_query($conn,"UPDATE hero SET name_hero='".$_POST['namahero']."',id_role='".$_POST['role']."',image='$nama',deskripsi='".$_POST['deskripsi']."' WHERE id_hero='".$_GET['id']."'");
					if($query){
						echo '<meta http-equiv="refresh" content="0; url=index.php">';
					}else{
						echo 'GAGAL MENGUPLOAD GAMBAR';
					}
				}else{
					echo 'UKURAN FILE TERLALU BESAR';
				}
			}else{
				echo 'EKSTENSI FILE YANG DI UPLOAD TIDAK DI PERBOLEHKAN';
			}
		}else{
			$conn = mysqli_connect("localhost","root","","webrole");
			$query = mysqli_query($conn,"UPDATE hero SET name_hero='".$_POST['namahero']."',id_role='".$_POST['role']."',deskripsi='".$_POST['deskripsi']."' WHERE id_hero='".$_GET['id']."'");
			if($query){
				echo '<meta http-equiv="refresh" content="0; url=index.php">';
			}		
		}
	}
?>
