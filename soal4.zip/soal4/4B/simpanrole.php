<?php
	if(@$_POST['simpan'])
	{
		echo "a";
		$conn = mysqli_connect("localhost","root","","webrole");
		$query = mysqli_query($conn,"INSERT INTO role VALUES('".$_POST['nama']."')");
		
		if($query){
			header('location:index.php');
		}
	}
?>
