<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Hero | WEB Role</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">HERO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="inputrole.php">Tambah Role</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="inputhero.php">Tambah Hero</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">
	<br>
    <!-- Page Features -->
    <div class="row text-center">
	<div class="box box-lg col-md-8">
	<form action="#" method="POST">
	  <div class="form-group row">
		<label for="inputPassword3" class="col-sm-2 col-form-label">Nama role</label>
		<div class="col-sm-10">
		  <input type="text" name="nama" required class="form-control" id="inputPassword3" placeholder="Masukan Nama Role">
		</div>
	  </div>
		<div class="col-sm-10">
		  <input type="submit" name="simpan" class="btn btn-primary" value="Simpan">
		  <button type="Reset" class="btn btn-warning">Reset</button>
		</div>
	</form>
    </div>
	</div>
	<br>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Ipur Purnama 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
<?php
	if(@$_POST['simpan'])
	{
		$conn = mysqli_connect("localhost","root","","webrole");
		$query = mysqli_query($conn,"INSERT INTO role VALUES(null,'".$_POST['nama']."')");
		
		if($query){
			header('location:index.php');
		}
	}
?>
