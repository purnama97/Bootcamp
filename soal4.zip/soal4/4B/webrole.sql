-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2020 at 04:13 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webrole`
--

-- --------------------------------------------------------

--
-- Table structure for table `hero`
--

CREATE TABLE `hero` (
  `id_hero` int(11) NOT NULL,
  `name_hero` varchar(25) NOT NULL,
  `id_role` int(11) NOT NULL,
  `image` varchar(20) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hero`
--

INSERT INTO `hero` (`id_hero`, `name_hero`, `id_role`, `image`, `deskripsi`) VALUES
(11, 'Axe', 6, 'drow ranger.jpg', 'Hero tank juga tidak luput dari perhatian, mengingat semua peran sangat bergantung di satu kemenangan Dota 2. Selain Axe, banyak tank yang bisa kamu gunakan, namun Axe termasuk yang termudah. Kamu hanya menggunakan tiga hero yang ada dengan serangan yang ofensif. Pemilihan waktu yang tepat mampu menyulitkan musuh di lane-mu.'),
(12, 'Chen', 6, 'Chen.jpg', 'Chen adalah Support yang paling enak di DotA. Chen bisa memiliki banyak pasukan yang bisa membantu di war dan siap mengobrak-abrik base musuh. dan yang paling spesial darinya adalah dia memiliki kemampuan Heal Global untuk seluruh teman-temannya, dimanapun mereka berada.'),
(13, 'Batrider', 3, 'clockwerk.jpg', 'Batrider adalah hero intelligence jarak jauh dengan kemampuan yang unik. Meskipun punya atribut utama intelligence, ia dikenal sebagai hero dengan kemampuan inisiasi yang sangat baik.\r\n\r\nMelengkapi itu, ia juga punya kemampuan laning yang cukup kuat. Lalu meskipun tidak begitu kuat, ia juga punya escape mechanism yang kadang sulit ditangani oleh lawan.\r\n\r\nHero ini sering digunakan di offlane berkat kemampuannya dalam melakukan harass serta kabur dari ancaman. Namun kadang ia juga dipasang di mid. Apapun posisinya, ia selalu memegang peran penting dalam inisiasi di timnya.');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'Tank'),
(2, 'Assassin'),
(3, 'Fighter'),
(5, 'Marksman'),
(6, 'Support'),
(7, 'Mage');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hero`
--
ALTER TABLE `hero`
  ADD PRIMARY KEY (`id_hero`),
  ADD KEY `id_role` (`id_role`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hero`
--
ALTER TABLE `hero`
  MODIFY `id_hero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hero`
--
ALTER TABLE `hero`
  ADD CONSTRAINT `hero_ibfk_1` FOREIGN KEY (`id_role`) REFERENCES `role` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
